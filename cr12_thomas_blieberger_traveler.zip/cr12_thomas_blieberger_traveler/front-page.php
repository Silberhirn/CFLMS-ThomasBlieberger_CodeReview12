
<?php get_header(); ?>

<div class="container">
        
<div class="row">
        
                <img class="img-responsive col-12" src="<?php echo get_template_directory_uri(); ?>/img/image.jpg" alt="image">
</div>

</div>

<?php get_footer(); ?>