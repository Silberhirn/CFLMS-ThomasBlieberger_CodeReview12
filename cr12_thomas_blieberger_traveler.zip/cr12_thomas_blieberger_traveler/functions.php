<?php 


function codefactory_files(){

//register jQuery
wp_enqueue_script('jquery','https://code.jquery.com/jquery-3.5.0.min.js', array(),'1.0', true);


// register bootstrap.css file
wp_enqueue_style('bootstrap-css', get_template_directory_uri().'/css/bootstrap.css');
// register bootstrap.js file
wp_enqueue_script('bootstrap-js', get_template_directory_uri().'/js/bootstrap.js', array(),'1.0', true);
// register style.css file
wp_enqueue_style('my-style-sheet', get_template_directory_uri().'/style.css');

}

//add the action of calling codefactory_files when the scripts are loaded
add_action('wp_enqueue_scripts', 'codefactory_files');


/**
* Register Custom Navigation Walker
*/
function register_navwalker(){

        // register the navwalker file
        require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';

        register_nav_menus( array(
   'primary' => __( 'Top-Menu'),
) );
}
add_action( 'after_setup_theme', 'register_navwalker' );


function set_excerpt_length(){
        return 10; //the number of words you want displayed
}
add_filter('excerpt_length','set_excerpt_length');

add_theme_support('post-thumbnails');

//Widget - sidebar
function wpb_init_widgets(){
   register_sidebar(array(
       'name' => 'Topbar',
       'id' => 'topbar',
       'before_widget' => '<div class="sidebar-module">',
       'after_widget' => '</div>',
       'before_title' => '<h4>',
       'after_title' => '</h4>'
        ));
}
add_action('widgets_init', 'wpb_init_widgets');

function gb_comment_form_tweaks ($fields) {
    //add placeholders and remove labels
    $fields['author'] = '<input id="author" name="author" value="" placeholder="Name*" size="30" maxlength="245" required="required" type="text">';

    $fields['email'] = '<input id="email" name="email" type="email" value="" placeholder="Email*" size="30" maxlength="100" aria-describedby="email-notes" required="required">';	

    //unset comment so we can recreate it at the bottom
    unset($fields['comment']);

    $fields['comment'] = '<textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" placeholder="Comment*" required="required"></textarea>';

    //remove website
    unset($fields['url']);

    return $fields;
}

add_filter('comment_form_fields', 'gb_comment_form_tweaks');

comment_form(array('title_reply' => 'Join the discussion!', 'comment_notes_before' => ''));
?>