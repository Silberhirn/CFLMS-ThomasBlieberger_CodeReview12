<?php get_header(); ?>
    <div class="p-0 m-auto d-flex justify-content-center"><?php
      if(is_active_sidebar('topbar')):
     dynamic_sidebar('topbar');
     endif;  
?></div>   
<div class="container">

       <?php if(have_posts()) : ?> <!--  If there are posts available  -->

       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop
-->
<div class="m-auto p-3">
  <div class="post p-3">       
           <h1 class="text-center m-3"><?php the_title(); ?></h1>    <!--retrieves blog title-->


       
       <?php the_content(); ?><!--retrieves content-->
       <small><p class="text-muted m-0"><?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->

       <p class="text-muted m-0"> <?php the_author(); ?></p></small><!--retrieves author of blog entry-->
       <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>
       <?php endif; ?> <!-- end if -->
   </div>

<div class="comments m-5"><?php    if (comments_open()){
    comments_template();
} ?>
</div>
</div>
</div>
 <?php get_footer(); ?>