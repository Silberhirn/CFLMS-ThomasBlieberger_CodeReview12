

<?php get_header(); ?>
   	<div class="col-2 p-0 m-auto d-flex justify-content-center"><?php
      if(is_active_sidebar('topbar')):
     dynamic_sidebar('topbar');
     endif;  
?></div>

<div class="d-flex justify-content-around flex-wrap m-auto">
       <?php if(have_posts()) : ?> <!--  If there are posts available  -->

       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop-->

       <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 p-3">
       	<div class="p-3 post">
       <?php if(has_post_thumbnail()) : ?>
		<?php the_post_thumbnail(); ?>
		<?php endif; ?>
       <h3 class="m-2 text-center"><a href="<?php the_permalink(); ?>"><!--retrieves URL for the permalink-->
          <?php the_title(); ?>    <!--retrieves blog title-->
       </a></h3>
       
       <p class="text-justify"><?php the_excerpt(); ?></p><!--retrieves content-->
		<small><p class="time m-0 text-muted"><?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->		
		<p class="author m-0 text-muted"> <?php the_author(); ?></p></small><!--retrieves author of blog entry-->     
</div>
</div>
       <?php endwhile; ?><!--end the while loop-->

       <?php else :?> <!-- if no posts are found then: -->

       <p>No posts found</p>  <!-- no posts found displayed -->
       <?php endif; ?> <!-- end if -->
   </div>
</div>


<?php get_footer(); ?>

</html>